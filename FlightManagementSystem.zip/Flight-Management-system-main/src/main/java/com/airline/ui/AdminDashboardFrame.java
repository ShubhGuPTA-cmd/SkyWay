package com.airline.ui;

import com.airline.service.*;
import com.airline.model.*;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.List;
import java.util.Map;

import static com.airline.ui.LoginFrame.*;

public class AdminDashboardFrame extends JFrame {
    private final AuthService authService;
    private final AdminService adminService;
    private final ReportService reportService;

    static final Color TAB_BG   = new Color(12, 22, 52);
    static final Color ROW_ALT  = new Color(18, 32, 68);
    static final Color HEADER_BG= new Color(20, 38, 80);

    public AdminDashboardFrame(AuthService authService) {
        this.authService = authService;
        this.adminService = new AdminService();
        this.reportService = new ReportService();
        initializeUI();
    }

    private void initializeUI() {
        setTitle("SkyWay Admin — " + authService.getCurrentUser().getFullName());
        setSize(1100, 720);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout()) {{ setBackground(BG_DARK); }};

        // ── Top bar ──────────────────────────────────────────────
        JPanel topBar = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g;
                g2.setColor(BG_CARD); g2.fillRect(0,0,getWidth(),getHeight());
                g2.setColor(BORDER); g2.drawLine(0,getHeight()-1,getWidth(),getHeight()-1);
            }
        };
        topBar.setOpaque(false); topBar.setBorder(BorderFactory.createEmptyBorder(14,24,14,24));

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT,12,0)) {{ setOpaque(false); }};
        JLabel plane = new JLabel("✈") {{ setFont(new Font("Segoe UI Emoji",Font.PLAIN,28)); setForeground(ACCENT); }};
        JLabel sysName = new JLabel("SkyWay") {{ setFont(new Font("Segoe UI",Font.BOLD,20)); setForeground(TEXT_PRIMARY); }};
        JLabel badge = new JLabel("ADMIN") {{
            setFont(new Font("Segoe UI",Font.BOLD,10)); setForeground(new Color(255,180,50));
            setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(255,180,50),1,true),BorderFactory.createEmptyBorder(2,7,2,7)));
        }};
        left.add(plane); left.add(sysName); left.add(badge);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT,12,0)) {{ setOpaque(false); }};
        JLabel user = new JLabel("👤  " + authService.getCurrentUser().getFullName()) {{ setFont(new Font("Segoe UI",Font.PLAIN,13)); setForeground(TEXT_MUTED); }};
        JButton logout = makeSBtn("Logout", new Color(200,50,50), new Color(160,30,30));
        logout.addActionListener(e -> { authService.logout(); new LoginFrame(authService).setVisible(true); dispose(); });
        right.add(user); right.add(logout);

        topBar.add(left,BorderLayout.WEST); topBar.add(right,BorderLayout.EAST);

        // ── Tabs ─────────────────────────────────────────────────
        JTabbedPane tabs = new JTabbedPane() {{
            setBackground(TAB_BG); setForeground(TEXT_PRIMARY);
            setFont(new Font("Segoe UI",Font.PLAIN,13));
        }};

        tabs.addTab("📊  Dashboard", createDashboard());
        tabs.addTab("✈  Airlines",   createTablePanel(new String[]{"ID","Code","Name","Country"}, this::loadAirlines, null));
        tabs.addTab("🏢  Airports",   createTablePanel(new String[]{"ID","Code","Name","City","Country"}, this::loadAirports, null));
        tabs.addTab("🛫  Flights",    createFlightsPanel());
        tabs.addTab("🎫  Bookings",   createTablePanel(new String[]{"PNR","Customer","Flight","Route","Passengers","Amount","Status"}, this::loadBookings, null));

        root.add(topBar, BorderLayout.NORTH);
        root.add(tabs, BorderLayout.CENTER);
        add(root);
    }

    private JPanel createDashboard() {
        JPanel panel = new JPanel(new BorderLayout()) {{ setBackground(BG_DARK); setBorder(BorderFactory.createEmptyBorder(28,28,28,28)); }};
        JLabel heading = new JLabel("Overview") {{ setFont(new Font("Segoe UI",Font.BOLD,22)); setForeground(TEXT_PRIMARY); }};
        panel.add(heading, BorderLayout.NORTH);

        JPanel cards = new JPanel(new GridLayout(1,5,16,0)) {{ setOpaque(false); setBorder(BorderFactory.createEmptyBorder(20,0,0,0)); }};
        Map<String,Object> s = reportService.getBookingStatistics();
        addCard(cards,"Total Bookings", s.get("totalBookings").toString(), ACCENT, "🎫");
        addCard(cards,"Confirmed",      s.get("confirmedBookings").toString(), new Color(50,205,130), "✅");
        addCard(cards,"Cancelled",      s.get("cancelledBookings").toString(), new Color(255,80,80), "❌");
        addCard(cards,"Completed",      s.get("completedBookings").toString(), new Color(180,100,255), "🏁");
        addCard(cards,"Revenue",        "₹"+String.format("%.0f",s.get("totalRevenue")), new Color(255,180,50), "💰");
        panel.add(cards, BorderLayout.CENTER);
        return panel;
    }

    private void addCard(JPanel p, String title, String val, Color accent, String icon) {
        JPanel card = new JPanel(new BorderLayout(0,10)) {
            @Override protected void paintComponent(Graphics g){
                Graphics2D g2=(Graphics2D)g; g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(BG_CARD); g2.fillRoundRect(0,0,getWidth(),getHeight(),16,16);
                g2.setColor(accent); g2.setStroke(new BasicStroke(2)); g2.drawLine(0,getHeight()-2,getWidth(),getHeight()-2);
                GradientPaint gp=new GradientPaint(0,0,new Color(accent.getRed()/6,accent.getGreen()/6,accent.getBlue()/6),0,getHeight(),new Color(8,15,36));
                g2.setPaint(gp); g2.fillRoundRect(0,0,getWidth(),getHeight(),16,16);
            }
        };
        card.setOpaque(false); card.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));
        JLabel ico = new JLabel(icon) {{ setFont(new Font("Segoe UI Emoji",Font.PLAIN,28)); }};
        JLabel t   = new JLabel(title) {{ setFont(new Font("Segoe UI",Font.PLAIN,12)); setForeground(TEXT_MUTED); }};
        JLabel v   = new JLabel(val)   {{ setFont(new Font("Segoe UI",Font.BOLD,26)); setForeground(TEXT_PRIMARY); }};
        JPanel top = new JPanel(new BorderLayout()) {{ setOpaque(false); add(t,BorderLayout.WEST); add(ico,BorderLayout.EAST); }};
        card.add(top,BorderLayout.NORTH); card.add(v,BorderLayout.CENTER);
        p.add(card);
    }

    interface TableLoader { void load(DefaultTableModel m); }

    private JPanel createTablePanel(String[] cols, TableLoader loader, Runnable extra) {
        JPanel panel = new JPanel(new BorderLayout(0,12)) {{ setBackground(BG_DARK); setBorder(BorderFactory.createEmptyBorder(16,20,16,20)); }};
        DefaultTableModel model = new DefaultTableModel(cols,0){ public boolean isCellEditable(int r,int c){return false;} };
        JTable table = styledTable(model);
        loader.load(model);
        JScrollPane sp = styledScroll(table);
        JPanel btns = new JPanel(new FlowLayout(FlowLayout.LEFT,10,0)) {{ setOpaque(false); }};
        JButton ref = makeSBtn("↻  Refresh", ACCENT, ACCENT_HOVER); ref.addActionListener(e->loader.load(model)); btns.add(ref);
        panel.add(sp,BorderLayout.CENTER); panel.add(btns,BorderLayout.SOUTH);
        return panel;
    }

    private JPanel createFlightsPanel() {
        JPanel panel = new JPanel(new BorderLayout(0,12)) {{ setBackground(BG_DARK); setBorder(BorderFactory.createEmptyBorder(16,20,16,20)); }};
        String[] cols = {"ID","Flight #","Airline","Route","Seats","Price","Status"};
        DefaultTableModel model = new DefaultTableModel(cols,0){ public boolean isCellEditable(int r,int c){return false;} };
        JTable table = styledTable(model);
        loadFlights(model);
        JScrollPane sp = styledScroll(table);
        JPanel btns = new JPanel(new FlowLayout(FlowLayout.LEFT,10,0)) {{ setOpaque(false); }};
        JButton ref = makeSBtn("↻  Refresh", ACCENT, ACCENT_HOVER); ref.addActionListener(e->loadFlights(model));
        JButton add = makeSBtn("+ Add Flight", new Color(50,180,100), new Color(35,140,75)); add.addActionListener(e->showAddFlightDialog(model));
        btns.add(ref); btns.add(add);
        panel.add(sp,BorderLayout.CENTER); panel.add(btns,BorderLayout.SOUTH);
        return panel;
    }

    private JTable styledTable(DefaultTableModel model) {
        JTable t = new JTable(model);
        t.setFont(new Font("Segoe UI",Font.PLAIN,13)); t.setRowHeight(34);
        t.setBackground(TAB_BG); t.setForeground(TEXT_PRIMARY);
        t.setSelectionBackground(new Color(30,70,150)); t.setSelectionForeground(TEXT_PRIMARY);
        t.setGridColor(BORDER); t.setShowHorizontalLines(true); t.setShowVerticalLines(false);
        t.getTableHeader().setFont(new Font("Segoe UI",Font.BOLD,12));
        t.getTableHeader().setBackground(HEADER_BG); t.getTableHeader().setForeground(TEXT_MUTED);
        t.getTableHeader().setBorder(BorderFactory.createMatteBorder(0,0,1,0,BORDER));
        t.setDefaultRenderer(Object.class, new DefaultTableCellRenderer(){
            @Override public Component getTableCellRendererComponent(JTable tbl,Object val,boolean sel,boolean foc,int row,int col){
                super.getTableCellRendererComponent(tbl,val,sel,foc,row,col);
                setBackground(sel?new Color(30,70,150):row%2==0?TAB_BG:ROW_ALT);
                setForeground(TEXT_PRIMARY); setBorder(BorderFactory.createEmptyBorder(0,12,0,12));
                return this;
            }
        });
        return t;
    }

    private JScrollPane styledScroll(JTable t) {
        JScrollPane sp = new JScrollPane(t);
        sp.setBorder(BorderFactory.createLineBorder(BORDER,1));
        sp.getViewport().setBackground(TAB_BG);
        sp.setBackground(BG_CARD);
        return sp;
    }

    private JButton makeSBtn(String text, Color bg, Color hover) {
        JButton b = new JButton(text) {
            @Override protected void paintComponent(Graphics g){
                Graphics2D g2=(Graphics2D)g; g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover()||getModel().isPressed()?hover:bg); g2.fillRoundRect(0,0,getWidth(),getHeight(),8,8);
                super.paintComponent(g);
            }
        };
        b.setFont(new Font("Segoe UI",Font.BOLD,12)); b.setForeground(Color.WHITE);
        b.setFocusPainted(false); b.setBorderPainted(false); b.setContentAreaFilled(false);
        b.setBorder(BorderFactory.createEmptyBorder(8,16,8,16)); b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return b;
    }

    private void loadAirlines(DefaultTableModel m) {
        m.setRowCount(0);
        for (Airline a : adminService.getAllAirlines()) m.addRow(new Object[]{a.getAirlineId(),a.getAirlineCode(),a.getAirlineName(),a.getCountry()});
    }
    private void loadAirports(DefaultTableModel m) {
        m.setRowCount(0);
        for (Airport a : adminService.getAllAirports()) m.addRow(new Object[]{a.getAirportId(),a.getAirportCode(),a.getAirportName(),a.getCity(),a.getCountry()});
    }
    private void loadFlights(DefaultTableModel m) {
        m.setRowCount(0);
        for (Flight f : adminService.getAllFlights()) m.addRow(new Object[]{f.getFlightId(),f.getFlightNumber(),f.getAirlineName(),f.getOriginCity()+" → "+f.getDestinationCity(),f.getTotalSeats(),"₹"+f.getBasePrice(),f.getStatus()});
    }
    private void loadBookings(DefaultTableModel m) {
        m.setRowCount(0);
        for (Booking b : adminService.getAllBookings()) m.addRow(new Object[]{b.getPnr(),b.getCustomerName(),b.getFlightNumber(),b.getOriginCity()+" → "+b.getDestinationCity(),b.getTotalPassengers(),"₹"+b.getTotalAmount(),b.getStatus()});
    }

    private void showAddFlightDialog(DefaultTableModel model) {
        JDialog d = new JDialog(this,"Add New Flight",true);
        d.setSize(540,680); d.setLocationRelativeTo(this);
        JPanel p = new JPanel() {{ setBackground(BG_DARK); }};
        p.setLayout(new BoxLayout(p,BoxLayout.Y_AXIS));
        p.setBorder(BorderFactory.createEmptyBorder(28,36,28,36));

        JLabel t = new JLabel("Add New Flight") {{ setFont(new Font("Segoe UI",Font.BOLD,22)); setForeground(TEXT_PRIMARY); setAlignmentX(CENTER_ALIGNMENT); }};
        JLabel sub = new JLabel("Flight details + first schedule") {{ setFont(new Font("Segoe UI",Font.PLAIN,12)); setForeground(TEXT_MUTED); setAlignmentX(CENTER_ALIGNMENT); }};
        p.add(t); p.add(Box.createVerticalStrut(4)); p.add(sub); p.add(Box.createVerticalStrut(20));

        JTextField fnField = mkDField("e.g. AI201");
        JTextField seatsField = mkDField("e.g. 180");
        JTextField priceField = mkDField("e.g. 4500");
        JTextField deptField = mkDField("yyyy-MM-dd HH:mm  e.g. 2026-05-01 10:30");
        JTextField arrField  = mkDField("yyyy-MM-dd HH:mm  e.g. 2026-05-01 12:30");

        List<Airline> airlines = adminService.getAllAirlines();
        JComboBox<Airline> airCb = new JComboBox<>(airlines.toArray(new Airline[0])); styleCb(airCb);
        List<Airport> airports = adminService.getAllAirports();
        JComboBox<Airport> origCb = new JComboBox<>(airports.toArray(new Airport[0])); styleCb(origCb);
        JComboBox<Airport> destCb = new JComboBox<>(airports.toArray(new Airport[0])); styleCb(destCb);
        JComboBox<Flight.FlightStatus> stCb = new JComboBox<>(Flight.FlightStatus.values());
        stCb.setSelectedItem(Flight.FlightStatus.ACTIVE); styleCb(stCb);

        addDRow(p,"Flight Number", fnField);
        addDRow(p,"Airline", airCb);
        addDRow(p,"Origin Airport", origCb);
        addDRow(p,"Destination Airport", destCb);
        JPanel row = new JPanel() {{ setLayout(new BoxLayout(this,BoxLayout.X_AXIS)); setOpaque(false); setMaximumSize(new Dimension(Integer.MAX_VALUE,70)); setAlignmentX(LEFT_ALIGNMENT); }};
        JPanel s1 = mkDBlock("Total Seats",seatsField), s2 = mkDBlock("Base Price (₹)",priceField);
        row.add(s1); row.add(Box.createHorizontalStrut(12)); row.add(s2);
        p.add(row); p.add(Box.createVerticalStrut(10));
        addDRow(p,"Status", stCb);

        // Schedule section
        JSeparator sep = new JSeparator(); sep.setForeground(BORDER); sep.setMaximumSize(new Dimension(Integer.MAX_VALUE,1));
        p.add(Box.createVerticalStrut(10)); p.add(sep); p.add(Box.createVerticalStrut(10));
        JLabel schedLabel = new JLabel("Schedule (First Departure)") {{ setFont(new Font("Segoe UI",Font.BOLD,14)); setForeground(ACCENT); setAlignmentX(LEFT_ALIGNMENT); }};
        p.add(schedLabel); p.add(Box.createVerticalStrut(10));
        addDRow(p,"Departure Time", deptField);
        addDRow(p,"Arrival Time",   arrField);
        p.add(Box.createVerticalStrut(16));

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.CENTER,12,0)) {{ setOpaque(false); }};
        JButton save = makeSBtn("Save Flight + Schedule", new Color(50,180,100), new Color(35,140,75));
        save.addActionListener(e -> {
            try {
                if(fnField.getText().trim().isEmpty()){ JOptionPane.showMessageDialog(d,"Flight number required"); return; }
                if(deptField.getText().trim().isEmpty()||arrField.getText().trim().isEmpty()){ JOptionPane.showMessageDialog(d,"Departure and arrival time required"); return; }

                java.time.LocalDateTime dept, arr;
                java.time.format.DateTimeFormatter fmt = java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
                try {
                    dept = java.time.LocalDateTime.parse(deptField.getText().trim(), fmt);
                    arr  = java.time.LocalDateTime.parse(arrField.getText().trim(), fmt);
                } catch(Exception ex){ JOptionPane.showMessageDialog(d,"Invalid date format. Use: yyyy-MM-dd HH:mm"); return; }
                if(!arr.isAfter(dept)){ JOptionPane.showMessageDialog(d,"Arrival must be after departure"); return; }

                Flight f = new Flight();
                f.setFlightNumber(fnField.getText().trim().toUpperCase());
                f.setAirlineId(((Airline)airCb.getSelectedItem()).getAirlineId());
                f.setOriginAirportId(((Airport)origCb.getSelectedItem()).getAirportId());
                f.setDestinationAirportId(((Airport)destCb.getSelectedItem()).getAirportId());
                f.setTotalSeats(Integer.parseInt(seatsField.getText().trim()));
                f.setBasePrice(new java.math.BigDecimal(priceField.getText().trim()));
                f.setStatus((Flight.FlightStatus)stCb.getSelectedItem());
                if(f.getOriginAirportId()==f.getDestinationAirportId()){ JOptionPane.showMessageDialog(d,"Origin and destination must differ"); return; }

                if(adminService.createFlight(f)){
                    // Also create a schedule so it appears in search
                    Schedule sched = new Schedule();
                    sched.setFlightId(f.getFlightId());
                    sched.setDepartureTime(dept);
                    sched.setArrivalTime(arr);
                    sched.setAvailableSeats(f.getTotalSeats());
                    sched.setStatus(Schedule.ScheduleStatus.SCHEDULED);
                    adminService.createSchedule(sched);
                    JOptionPane.showMessageDialog(d,"Flight and schedule added successfully!","Success",JOptionPane.INFORMATION_MESSAGE);
                    loadFlights(model); d.dispose();
                } else JOptionPane.showMessageDialog(d,"Failed to add flight");
            } catch(Exception ex){ JOptionPane.showMessageDialog(d,"Invalid input: "+ex.getMessage()); }
        });
        JButton cancel = makeSBtn("Cancel", new Color(60,70,100), new Color(40,50,80)); cancel.addActionListener(e->d.dispose());
        btns.add(save); btns.add(cancel); p.add(btns);
        d.add(new JScrollPane(p) {{ setBorder(null); getViewport().setBackground(BG_DARK); }}); d.setVisible(true);
    }

    private JTextField mkDField(String ph){ JTextField f=new JTextField(); f.setFont(new Font("Segoe UI",Font.PLAIN,13)); f.setBackground(INPUT_BG); f.setForeground(TEXT_PRIMARY); f.setCaretColor(ACCENT); f.setMaximumSize(new Dimension(Integer.MAX_VALUE,40)); f.setAlignmentX(LEFT_ALIGNMENT); f.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(BORDER,1),BorderFactory.createEmptyBorder(8,12,8,12))); return f; }
    private void styleCb(JComboBox<?> cb){ cb.setFont(new Font("Segoe UI",Font.PLAIN,13)); cb.setBackground(INPUT_BG); cb.setForeground(TEXT_PRIMARY); cb.setMaximumSize(new Dimension(Integer.MAX_VALUE,40)); cb.setAlignmentX(LEFT_ALIGNMENT); }
    private void addDRow(JPanel p,String label,Component c){ JLabel l=new JLabel(label); l.setFont(new Font("Segoe UI",Font.PLAIN,12)); l.setForeground(TEXT_MUTED); l.setAlignmentX(LEFT_ALIGNMENT); p.add(l); p.add(Box.createVerticalStrut(5)); c.setMaximumSize(new Dimension(Integer.MAX_VALUE,40)); p.add(c); p.add(Box.createVerticalStrut(12)); }
    private JPanel mkDBlock(String label, JTextField f){ JPanel p=new JPanel(); p.setLayout(new BoxLayout(p,BoxLayout.Y_AXIS)); p.setOpaque(false); JLabel l=new JLabel(label); l.setFont(new Font("Segoe UI",Font.PLAIN,12)); l.setForeground(TEXT_MUTED); l.setAlignmentX(LEFT_ALIGNMENT); p.add(l); p.add(Box.createVerticalStrut(5)); p.add(f); return p; }
}
