package com.airline.ui;

import com.airline.service.AuthService;
import com.airline.util.Logger;

import javax.swing.*;
import java.awt.AlphaComposite;
import java.awt.*;
import java.awt.geom.*;

public class LoginFrame extends JFrame {
    private final AuthService authService;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JComboBox<String> roleComboBox;

    // Color palette
    static final Color BG_DARK      = new Color(8, 15, 36);
    static final Color BG_CARD      = new Color(16, 28, 60);
    static final Color ACCENT       = new Color(64, 156, 255);
    static final Color ACCENT_HOVER = new Color(40, 120, 220);
    static final Color TEXT_PRIMARY = new Color(230, 238, 255);
    static final Color TEXT_MUTED   = new Color(120, 145, 190);
    static final Color BORDER       = new Color(40, 65, 120);
    static final Color INPUT_BG     = new Color(12, 22, 50);
    static final Color SUCCESS      = new Color(50, 205, 130);

    public LoginFrame(AuthService authService) {
        this.authService = authService;
        initializeUI();
    }

    private void initializeUI() {
        setTitle("SkyWay — Airline Management");
        setSize(480, 640);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel mainPanel = new JPanel() {
            final float[] starX = new float[60], starY = new float[60], starA = new float[60];
            float tick = 0;
            { 
                java.util.Random r = new java.util.Random(42);
                for (int i = 0; i < 60; i++) { starX[i]=r.nextFloat()*480; starY[i]=r.nextFloat()*640; starA[i]=r.nextFloat(); }
                new Timer(60, e -> { tick+=0.02f; repaint(); }).start();
            }
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D)g;
                g2.setColor(BG_DARK); g2.fillRect(0,0,getWidth(),getHeight());
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                for (int i = 0; i < 60; i++) {
                    float a = (float)(0.3 + 0.4*Math.sin(tick + starA[i]*6.28));
                    g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, Math.max(0f,Math.min(1f,a))));
                    g2.setColor(Color.WHITE);
                    g2.fillOval((int)starX[i],(int)starY[i],2,2);
                    g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
                }
                GradientPaint glow = new GradientPaint(240,0,new Color(64,156,255),240,640,new Color(8,15,36));
                g2.setPaint(glow); g2.fillRect(0,0,480,640);
            }
        };
        mainPanel.setLayout(new GridBagLayout());

        JPanel card = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D)g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(BG_CARD); g2.fillRoundRect(0,0,getWidth()-1,getHeight()-1,24,24);
                g2.setColor(BORDER); g2.setStroke(new BasicStroke(1)); g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,24,24);
                GradientPaint shine = new GradientPaint(0,0,new Color(255,255,255),0,80,new Color(16,28,60));
                g2.setPaint(shine); g2.fillRoundRect(0,0,getWidth()-1,40,24,24);
            }
        };
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setOpaque(false);
        card.setBorder(BorderFactory.createEmptyBorder(40, 44, 40, 44));
        card.setPreferredSize(new Dimension(390, 560));

        // Plane icon
        JLabel planeLabel = new JLabel("✈") {{ setFont(new Font("Segoe UI Emoji",Font.PLAIN,48)); setForeground(ACCENT); setAlignmentX(CENTER_ALIGNMENT); }};
        card.add(planeLabel);
        card.add(Box.createVerticalStrut(12));

        // Title
        JLabel title = new JLabel("SkyWay") {{ setFont(new Font("Segoe UI",Font.BOLD,30)); setForeground(TEXT_PRIMARY); setAlignmentX(CENTER_ALIGNMENT); }};
        JLabel sub   = new JLabel("Airline Management System") {{ setFont(new Font("Segoe UI",Font.PLAIN,13)); setForeground(TEXT_MUTED); setAlignmentX(CENTER_ALIGNMENT); }};
        card.add(title); card.add(Box.createVerticalStrut(4)); card.add(sub);
        card.add(Box.createVerticalStrut(32));

        // Fields
        card.add(makeLabel("Username")); card.add(Box.createVerticalStrut(6));
        usernameField = makeTextField("Enter your username");
        card.add(usernameField); card.add(Box.createVerticalStrut(16));

        card.add(makeLabel("Password")); card.add(Box.createVerticalStrut(6));
        passwordField = new JPasswordField();
        styleField(passwordField, "Enter your password");
        card.add(passwordField); card.add(Box.createVerticalStrut(16));

        card.add(makeLabel("Login As")); card.add(Box.createVerticalStrut(6));
        roleComboBox = new JComboBox<>(new String[]{"Customer", "Admin"});
        roleComboBox.setFont(new Font("Segoe UI",Font.PLAIN,14));
        roleComboBox.setBackground(INPUT_BG); roleComboBox.setForeground(TEXT_PRIMARY);
        roleComboBox.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        roleComboBox.setAlignmentX(CENTER_ALIGNMENT);
        roleComboBox.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER,1,true),
            BorderFactory.createEmptyBorder(0,12,0,0)));
        card.add(roleComboBox); card.add(Box.createVerticalStrut(28));

        // Login button
        JButton loginBtn = makeButton("Sign In", ACCENT, ACCENT_HOVER);
        loginBtn.addActionListener(e -> handleLogin());
        card.add(loginBtn); card.add(Box.createVerticalStrut(12));

        // Register button
        JButton regBtn = makeOutlineButton("Create New Account");
        regBtn.addActionListener(e -> openRegistrationForm());
        card.add(regBtn);

        mainPanel.add(card);
        add(mainPanel);
        passwordField.addActionListener(e -> handleLogin());
    }

    private JLabel makeLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("Segoe UI",Font.PLAIN,13));
        l.setForeground(TEXT_MUTED);
        l.setAlignmentX(LEFT_ALIGNMENT);
        return l;
    }

    private JTextField makeTextField(String placeholder) {
        JTextField f = new JTextField();
        styleField(f, placeholder);
        return f;
    }

    private void styleField(JTextField f, String ph) {
        f.setFont(new Font("Segoe UI",Font.PLAIN,14));
        f.setBackground(INPUT_BG); f.setForeground(TEXT_PRIMARY);
        f.setCaretColor(ACCENT);
        f.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        f.setAlignmentX(CENTER_ALIGNMENT);
        f.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(BORDER,1,true),
            BorderFactory.createEmptyBorder(10,14,10,14)));
        f.addFocusListener(new java.awt.event.FocusAdapter(){
            public void focusGained(java.awt.event.FocusEvent e){ f.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(ACCENT,2,true),BorderFactory.createEmptyBorder(9,13,9,13))); }
            public void focusLost(java.awt.event.FocusEvent e){ f.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(BORDER,1,true),BorderFactory.createEmptyBorder(10,14,10,14))); }
        });
    }

    private JButton makeButton(String text, Color bg, Color hover) {
        JButton b = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g; g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover()||getModel().isPressed()?hover:bg);
                g2.fillRoundRect(0,0,getWidth(),getHeight(),12,12);
                super.paintComponent(g);
            }
        };
        b.setFont(new Font("Segoe UI",Font.BOLD,15)); b.setForeground(Color.WHITE);
        b.setFocusPainted(false); b.setBorderPainted(false); b.setContentAreaFilled(false);
        b.setMaximumSize(new Dimension(Integer.MAX_VALUE,46)); b.setAlignmentX(CENTER_ALIGNMENT);
        b.setBorder(BorderFactory.createEmptyBorder(12,0,12,0));
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return b;
    }

    private JButton makeOutlineButton(String text) {
        JButton b = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g; g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover()?new Color(30,60,120):new Color(16,28,60));
                g2.fillRoundRect(0,0,getWidth(),getHeight(),12,12);
                g2.setColor(ACCENT); g2.setStroke(new BasicStroke(1.5f));
                g2.drawRoundRect(1,1,getWidth()-2,getHeight()-2,12,12);
                super.paintComponent(g);
            }
        };
        b.setFont(new Font("Segoe UI",Font.PLAIN,14)); b.setForeground(ACCENT);
        b.setFocusPainted(false); b.setBorderPainted(false); b.setContentAreaFilled(false);
        b.setMaximumSize(new Dimension(Integer.MAX_VALUE,44)); b.setAlignmentX(CENTER_ALIGNMENT);
        b.setBorder(BorderFactory.createEmptyBorder(10,0,10,0));
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return b;
    }

    private void handleLogin() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());
        String role = (String)roleComboBox.getSelectedItem();
        if (username.isEmpty()||password.isEmpty()) { JOptionPane.showMessageDialog(this,"Please enter username and password","Error",JOptionPane.ERROR_MESSAGE); return; }
        if (authService.login(username,password)) {
            boolean isAdmin = authService.isAdmin(), wantsAdmin = "Admin".equals(role);
            if (!isAdmin && wantsAdmin) { JOptionPane.showMessageDialog(this,"Access Denied: No admin privileges","Error",JOptionPane.ERROR_MESSAGE); authService.logout(); return; }
            Logger.info("Login: "+username); dispose();
            if (wantsAdmin) new AdminDashboardFrame(authService).setVisible(true);
            else new CustomerDashboardFrame(authService).setVisible(true);
        } else { JOptionPane.showMessageDialog(this,"Invalid username or password","Login Failed",JOptionPane.ERROR_MESSAGE); passwordField.setText(""); }
    }

    private void openRegistrationForm() { new RegisterFrame(authService).setVisible(true); dispose(); }
}
