package com.airline.ui;

import com.airline.service.*;
import com.airline.model.Booking;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.List;

import static com.airline.ui.LoginFrame.*;
import static com.airline.ui.AdminDashboardFrame.*;

public class CustomerDashboardFrame extends JFrame {
    private final AuthService authService;
    private final BookingService bookingService;

    public CustomerDashboardFrame(AuthService authService) {
        this.authService = authService;
        this.bookingService = new BookingService();
        initializeUI();
    }

    private void initializeUI() {
        setTitle("SkyWay — " + authService.getCurrentUser().getFullName());
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout()) {{ setBackground(BG_DARK); }};

        // ── Top bar ──────────────────────────────────────────────
        JPanel topBar = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g;
                GradientPaint gp=new GradientPaint(0,0,new Color(10,30,80),getWidth(),0,new Color(30,60,120));
                g2.setPaint(gp); g2.fillRect(0,0,getWidth(),getHeight());
                g2.setColor(BORDER); g2.drawLine(0,getHeight()-1,getWidth(),getHeight()-1);
            }
        };
        topBar.setOpaque(false); topBar.setBorder(BorderFactory.createEmptyBorder(16,24,16,24));

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT,12,0)) {{ setOpaque(false); }};
        JLabel plane = new JLabel("✈") {{ setFont(new Font("Segoe UI Emoji",Font.PLAIN,28)); setForeground(ACCENT); }};
        JLabel sysName = new JLabel("SkyWay") {{ setFont(new Font("Segoe UI",Font.BOLD,20)); setForeground(TEXT_PRIMARY); }};
        JPanel userInfo = new JPanel() {{ setOpaque(false); setLayout(new BoxLayout(this,BoxLayout.Y_AXIS)); }};
        JLabel wlc = new JLabel("Welcome back") {{ setFont(new Font("Segoe UI",Font.PLAIN,11)); setForeground(TEXT_MUTED); }};
        JLabel uname = new JLabel(authService.getCurrentUser().getFullName()) {{ setFont(new Font("Segoe UI",Font.BOLD,16)); setForeground(TEXT_PRIMARY); }};
        userInfo.add(wlc); userInfo.add(uname);
        left.add(plane); left.add(Box.createHorizontalStrut(8)); left.add(sysName); left.add(Box.createHorizontalStrut(20)); left.add(userInfo);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT,12,0)) {{ setOpaque(false); }};
        JButton logout = makeSBtn("Logout", new Color(200,50,50), new Color(160,30,30));
        logout.addActionListener(e -> { authService.logout(); new LoginFrame(authService).setVisible(true); dispose(); });
        right.add(logout);
        topBar.add(left,BorderLayout.WEST); topBar.add(right,BorderLayout.EAST);

        // ── Tabs ─────────────────────────────────────────────────
        UIManager.put("TabbedPane.background", new Color(12, 22, 52));
        UIManager.put("TabbedPane.foreground", new Color(180, 200, 240));
        UIManager.put("TabbedPane.selected", new Color(20, 40, 90));
        UIManager.put("TabbedPane.selectedForeground", new Color(230, 238, 255));
        UIManager.put("TabbedPane.unselectedBackground", new Color(12, 22, 52));
        UIManager.put("TabbedPane.tabAreaBackground", new Color(8, 15, 36));
        UIManager.put("TabbedPane.contentAreaColor", new Color(8, 15, 36));
        UIManager.put("TabbedPane.focus", new Color(64, 156, 255));
        UIManager.put("TabbedPane.selectHighlight", new Color(64, 156, 255));
        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tabs.setBackground(new Color(12, 22, 52));
        tabs.setForeground(new Color(180, 200, 240));
        tabs.setOpaque(true);

        JPanel bookingsPanel = createBookingsPanel();
        tabs.addTab("✈  Search Flights", createSearchPanel());
        tabs.addTab("🎫  My Bookings", bookingsPanel);
        tabs.addChangeListener(e -> { if(tabs.getSelectedIndex()==1) refreshTable(bookingsPanel); });

        root.add(topBar,BorderLayout.NORTH); root.add(tabs,BorderLayout.CENTER);
        add(root);
    }

    private JPanel createSearchPanel() {
        JPanel panel = new JPanel(new GridBagLayout()) {{ setBackground(BG_DARK); }};

        JPanel card = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g; g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(BG_CARD); g2.fillRoundRect(0,0,getWidth()-1,getHeight()-1,20,20);
                g2.setColor(BORDER); g2.setStroke(new BasicStroke(1)); g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,20,20);
            }
        };
        card.setLayout(new BoxLayout(card,BoxLayout.Y_AXIS));
        card.setOpaque(false); card.setBorder(BorderFactory.createEmptyBorder(40,50,40,50));
        card.setPreferredSize(new Dimension(460,320));

        JLabel ico = new JLabel("✈") {{ setFont(new Font("Segoe UI Emoji",Font.PLAIN,52)); setForeground(ACCENT); setAlignmentX(CENTER_ALIGNMENT); }};
        JLabel t = new JLabel("Find Your Flight") {{ setFont(new Font("Segoe UI",Font.BOLD,26)); setForeground(TEXT_PRIMARY); setAlignmentX(CENTER_ALIGNMENT); }};
        JLabel s = new JLabel("Search and book flights worldwide") {{ setFont(new Font("Segoe UI",Font.PLAIN,14)); setForeground(TEXT_MUTED); setAlignmentX(CENTER_ALIGNMENT); }};

        card.add(ico); card.add(Box.createVerticalStrut(14));
        card.add(t); card.add(Box.createVerticalStrut(6)); card.add(s);
        card.add(Box.createVerticalStrut(32));

        JButton searchBtn = new JButton("Search Flights") {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g; g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp=new GradientPaint(0,0,getModel().isRollover()?new Color(40,120,220):ACCENT,getWidth(),0,getModel().isRollover()?new Color(80,60,200):new Color(80,80,240));
                g2.setPaint(gp); g2.fillRoundRect(0,0,getWidth(),getHeight(),12,12);
                super.paintComponent(g);
            }
        };
        searchBtn.setFont(new Font("Segoe UI",Font.BOLD,15)); searchBtn.setForeground(Color.WHITE);
        searchBtn.setFocusPainted(false); searchBtn.setBorderPainted(false); searchBtn.setContentAreaFilled(false);
        searchBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE,48)); searchBtn.setAlignmentX(CENTER_ALIGNMENT);
        searchBtn.setBorder(BorderFactory.createEmptyBorder(12,0,12,0)); searchBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        searchBtn.addActionListener(e -> new FlightSearchFrame(authService, bookingService).setVisible(true));
        card.add(searchBtn);

        panel.add(card);
        return panel;
    }

    private JPanel createBookingsPanel() {
        JPanel panel = new JPanel(new BorderLayout(0,12)) {{ setBackground(BG_DARK); setBorder(BorderFactory.createEmptyBorder(20,20,20,20)); }};

        JLabel heading = new JLabel("My Bookings") {{ setFont(new Font("Segoe UI",Font.BOLD,20)); setForeground(TEXT_PRIMARY); }};
        panel.add(heading,BorderLayout.NORTH);

        String[] cols = {"PNR","Flight","Route","Departure","Status","Amount"};
        DefaultTableModel model = new DefaultTableModel(cols,0){ public boolean isCellEditable(int r,int c){return false;} };
        JTable table = styledTable(model);
        loadBookings(model);
        JScrollPane sp = styledScroll(table);

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.RIGHT,10,8)) {{ setOpaque(false); }};
        JButton ref = makeSBtn("↻  Refresh", ACCENT, ACCENT_HOVER);
        ref.addActionListener(e -> loadBookings(model));
        JButton cancel = makeSBtn("✕  Cancel Booking", new Color(200,50,80), new Color(160,30,60));
        cancel.addActionListener(e -> cancelBooking(table, model));
        btns.add(ref); btns.add(cancel);

        panel.add(sp,BorderLayout.CENTER); panel.add(btns,BorderLayout.SOUTH);
        return panel;
    }

    private void loadBookings(DefaultTableModel m) {
        m.setRowCount(0);
        for (Booking b : bookingService.getUserBookings(authService.getCurrentUser().getUserId()))
            m.addRow(new Object[]{b.getPnr(),b.getFlightNumber(),b.getOriginCity()+" → "+b.getDestinationCity(),b.getDepartureTime(),b.getStatus(),"₹"+b.getTotalAmount()});
    }

    private void refreshTable(JPanel panel) {
        for (Component c : panel.getComponents())
            if (c instanceof JScrollPane) { JTable t=(JTable)((JScrollPane)c).getViewport().getView(); loadBookings((DefaultTableModel)t.getModel()); break; }
    }

    private void cancelBooking(JTable table, DefaultTableModel model) {
        int row = table.getSelectedRow();
        if (row==-1) { JOptionPane.showMessageDialog(this,"Please select a booking to cancel"); return; }
        String pnr = (String)table.getValueAt(row,0);
        if (JOptionPane.showConfirmDialog(this,"Cancel booking "+pnr+"?","Confirm",JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION) {
            Booking b = bookingService.getBookingByPNR(pnr);
            if (b!=null&&bookingService.cancelBooking(b.getBookingId())) { JOptionPane.showMessageDialog(this,"Booking cancelled."); loadBookings(model); }
            else JOptionPane.showMessageDialog(this,"Failed to cancel booking.");
        }
    }

    private JTable styledTable(DefaultTableModel model) {
        JTable t = new JTable(model);
        t.setFont(new Font("Segoe UI",Font.PLAIN,13)); t.setRowHeight(34);
        t.setBackground(TAB_BG); t.setForeground(TEXT_PRIMARY);
        t.setSelectionBackground(new Color(30,70,150)); t.setSelectionForeground(TEXT_PRIMARY);
        t.setGridColor(BORDER); t.setShowHorizontalLines(true); t.setShowVerticalLines(false);
        t.getTableHeader().setFont(new Font("Segoe UI",Font.BOLD,12));
        t.getTableHeader().setBackground(HEADER_BG); t.getTableHeader().setForeground(TEXT_MUTED);
        t.getTableHeader().setBorder(BorderFactory.createMatteBorder(0,0,1,0,BORDER));
        t.setDefaultRenderer(Object.class, new DefaultTableCellRenderer(){
            @Override public Component getTableCellRendererComponent(JTable tbl,Object val,boolean sel,boolean foc,int row,int col){
                super.getTableCellRendererComponent(tbl,val,sel,foc,row,col);
                setBackground(sel?new Color(30,70,150):row%2==0?TAB_BG:ROW_ALT);
                setForeground(TEXT_PRIMARY); setBorder(BorderFactory.createEmptyBorder(0,12,0,12));
                return this;
            }
        });
        return t;
    }

    private JScrollPane styledScroll(JTable t) {
        JScrollPane sp = new JScrollPane(t);
        sp.setBorder(BorderFactory.createLineBorder(BORDER,1));
        sp.getViewport().setBackground(TAB_BG); sp.setBackground(BG_CARD);
        return sp;
    }

    private JButton makeSBtn(String text, Color bg, Color hover) {
        JButton b = new JButton(text) {
            @Override protected void paintComponent(Graphics g){
                Graphics2D g2=(Graphics2D)g; g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover()||getModel().isPressed()?hover:bg); g2.fillRoundRect(0,0,getWidth(),getHeight(),8,8);
                super.paintComponent(g);
            }
        };
        b.setFont(new Font("Segoe UI",Font.BOLD,12)); b.setForeground(Color.WHITE);
        b.setFocusPainted(false); b.setBorderPainted(false); b.setContentAreaFilled(false);
        b.setBorder(BorderFactory.createEmptyBorder(8,16,8,16)); b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return b;
    }
}
