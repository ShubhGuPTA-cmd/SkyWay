package com.airline.ui;

import com.airline.model.User;
import com.airline.service.AuthService;
import com.airline.util.Logger;

import javax.swing.*;
import java.awt.*;

import static com.airline.ui.LoginFrame.*;

public class RegisterFrame extends JFrame {
    private final AuthService authService;
    private JTextField usernameField, fullNameField, emailField, phoneField;
    private JPasswordField passwordField, confirmPasswordField;
    private JComboBox<String> roleComboBox;

    public RegisterFrame(AuthService authService) {
        this.authService = authService;
        initializeUI();
    }

    private void initializeUI() {
        setTitle("SkyWay — Create Account");
        setSize(500, 620);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel mainPanel = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g; g2.setColor(BG_DARK); g2.fillRect(0,0,getWidth(),getHeight());
                GradientPaint glow=new GradientPaint(250,0,new Color(64,156,255,15),250,620,new Color(8,15,36,0));
                g2.setPaint(glow); g2.fillRect(0,0,500,620);
            }
        };
        mainPanel.setLayout(new GridBagLayout());

        JPanel card = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2=(Graphics2D)g; g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(BG_CARD); g2.fillRoundRect(0,0,getWidth()-1,getHeight()-1,24,24);
                g2.setColor(BORDER); g2.setStroke(new BasicStroke(1)); g2.drawRoundRect(0,0,getWidth()-1,getHeight()-1,24,24);
            }
        };
        card.setLayout(new BoxLayout(card,BoxLayout.Y_AXIS));
        card.setOpaque(false);
        card.setBorder(BorderFactory.createEmptyBorder(36,44,36,44));
        card.setPreferredSize(new Dimension(420,560));

        JLabel title=new JLabel("Create Account"){{ setFont(new Font("Segoe UI",Font.BOLD,26)); setForeground(TEXT_PRIMARY); setAlignmentX(CENTER_ALIGNMENT); }};
        JLabel sub=new JLabel("Join SkyWay today"){{ setFont(new Font("Segoe UI",Font.PLAIN,13)); setForeground(TEXT_MUTED); setAlignmentX(CENTER_ALIGNMENT); }};
        card.add(title); card.add(Box.createVerticalStrut(4)); card.add(sub);
        card.add(Box.createVerticalStrut(28));

        // Two-column for name/username
        JPanel row1=makeRow();
        row1.add(makeFieldBlock("Full Name", fullNameField=makeField()));
        row1.add(Box.createHorizontalStrut(12));
        row1.add(makeFieldBlock("Username", usernameField=makeField()));
        card.add(row1); card.add(Box.createVerticalStrut(14));

        card.add(makeLabel("Email")); card.add(Box.createVerticalStrut(6));
        emailField=makeField(); card.add(emailField); card.add(Box.createVerticalStrut(14));

        card.add(makeLabel("Phone")); card.add(Box.createVerticalStrut(6));
        phoneField=makeField(); card.add(phoneField); card.add(Box.createVerticalStrut(14));

        JPanel row2=makeRow();
        passwordField=new JPasswordField(); styleField(passwordField);
        confirmPasswordField=new JPasswordField(); styleField(confirmPasswordField);
        row2.add(makeFieldBlock("Password",passwordField));
        row2.add(Box.createHorizontalStrut(12));
        row2.add(makeFieldBlock("Confirm Password",confirmPasswordField));
        card.add(row2); card.add(Box.createVerticalStrut(14));

        card.add(makeLabel("Role")); card.add(Box.createVerticalStrut(6));
        roleComboBox=new JComboBox<>(new String[]{"CUSTOMER","ADMIN"});
        roleComboBox.setFont(new Font("Segoe UI",Font.PLAIN,14));
        roleComboBox.setBackground(INPUT_BG); roleComboBox.setForeground(TEXT_PRIMARY);
        roleComboBox.setMaximumSize(new Dimension(Integer.MAX_VALUE,44)); roleComboBox.setAlignmentX(CENTER_ALIGNMENT);
        roleComboBox.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(BORDER,1,true),BorderFactory.createEmptyBorder(0,12,0,0)));
        card.add(roleComboBox); card.add(Box.createVerticalStrut(24));

        JButton regBtn=makeBtn("Create Account",ACCENT,ACCENT_HOVER);
        regBtn.addActionListener(e->handleRegistration());
        card.add(regBtn); card.add(Box.createVerticalStrut(10));

        JButton backBtn=makeBtn("Back to Login",new Color(25,45,90),new Color(40,65,120));
        backBtn.addActionListener(e->backToLogin());
        card.add(backBtn);

        mainPanel.add(card);
        add(mainPanel);
    }

    private JPanel makeRow(){ JPanel p=new JPanel(); p.setLayout(new BoxLayout(p,BoxLayout.X_AXIS)); p.setOpaque(false); p.setAlignmentX(LEFT_ALIGNMENT); p.setMaximumSize(new Dimension(Integer.MAX_VALUE,80)); return p; }

    private JPanel makeFieldBlock(String label, JTextField field){
        JPanel p=new JPanel(); p.setLayout(new BoxLayout(p,BoxLayout.Y_AXIS)); p.setOpaque(false);
        JLabel l=makeLabel(label); l.setAlignmentX(LEFT_ALIGNMENT); p.add(l); p.add(Box.createVerticalStrut(6)); p.add(field); return p;
    }

    private JLabel makeLabel(String t){ JLabel l=new JLabel(t); l.setFont(new Font("Segoe UI",Font.PLAIN,13)); l.setForeground(TEXT_MUTED); l.setAlignmentX(LEFT_ALIGNMENT); return l; }

    private JTextField makeField(){ JTextField f=new JTextField(); styleField(f); return f; }

    private void styleField(JTextField f){
        f.setFont(new Font("Segoe UI",Font.PLAIN,14)); f.setBackground(INPUT_BG); f.setForeground(TEXT_PRIMARY); f.setCaretColor(ACCENT);
        f.setMaximumSize(new Dimension(Integer.MAX_VALUE,44)); f.setAlignmentX(CENTER_ALIGNMENT);
        f.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(BORDER,1,true),BorderFactory.createEmptyBorder(10,14,10,14)));
        f.addFocusListener(new java.awt.event.FocusAdapter(){
            public void focusGained(java.awt.event.FocusEvent e){ f.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(ACCENT,2,true),BorderFactory.createEmptyBorder(9,13,9,13))); }
            public void focusLost(java.awt.event.FocusEvent e){ f.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(BORDER,1,true),BorderFactory.createEmptyBorder(10,14,10,14))); }
        });
    }

    private JButton makeBtn(String text, Color bg, Color hover){
        JButton b=new JButton(text){
            @Override protected void paintComponent(Graphics g){
                Graphics2D g2=(Graphics2D)g; g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover()||getModel().isPressed()?hover:bg); g2.fillRoundRect(0,0,getWidth(),getHeight(),12,12);
                super.paintComponent(g);
            }
        };
        b.setFont(new Font("Segoe UI",Font.BOLD,14)); b.setForeground(Color.WHITE);
        b.setFocusPainted(false); b.setBorderPainted(false); b.setContentAreaFilled(false);
        b.setMaximumSize(new Dimension(Integer.MAX_VALUE,44)); b.setAlignmentX(CENTER_ALIGNMENT);
        b.setBorder(BorderFactory.createEmptyBorder(10,0,10,0)); b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return b;
    }

    private void handleRegistration(){
        String username=usernameField.getText().trim(), password=new String(passwordField.getPassword()),
               confirm=new String(confirmPasswordField.getPassword()), fullName=fullNameField.getText().trim(),
               email=emailField.getText().trim(), phone=phoneField.getText().trim(), roleStr=(String)roleComboBox.getSelectedItem();
        if(username.isEmpty()||password.isEmpty()||fullName.isEmpty()||email.isEmpty()){ JOptionPane.showMessageDialog(this,"Please fill all required fields","Error",JOptionPane.ERROR_MESSAGE); return; }
        if(!password.equals(confirm)){ JOptionPane.showMessageDialog(this,"Passwords do not match","Error",JOptionPane.ERROR_MESSAGE); return; }
        if(password.length()<6){ JOptionPane.showMessageDialog(this,"Password must be at least 6 characters","Error",JOptionPane.ERROR_MESSAGE); return; }
        if(authService.register(username,password,fullName,email,phone,User.UserRole.valueOf(roleStr))){
            JOptionPane.showMessageDialog(this,"Account created! Please login.","Success",JOptionPane.INFORMATION_MESSAGE);
            Logger.info("Registered: "+username); backToLogin();
        } else { JOptionPane.showMessageDialog(this,"Registration failed.\nUsername or email may already exist.","Error",JOptionPane.ERROR_MESSAGE); }
    }

    private void backToLogin(){ new LoginFrame(authService).setVisible(true); dispose(); }
}
